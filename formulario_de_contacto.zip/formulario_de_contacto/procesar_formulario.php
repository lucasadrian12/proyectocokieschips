<?php
//Casilla de mail a la que se env�an los correos 
$destinatario='valeria.meijide@davinci.edu.ar';
//nombre del que env�a el correo 
$origen_nombre='www.vmei.com.ar';
//mail que aparece en el remitente 
$origen_mail='info@vmei.com.ar';
//asunto del correo 
$asunto='Contacto desde website';
//p�gina de agradecimiento 
$adondevoy='gracias.html';


//configuraci�n para mail()
$cabecera = "From: $origen_nombre <$origen_mail>\r\n";
$cabecera .= "Reply-To: $origen_mail\r\n"; 
$cabecera .= "Return-Path: $origen_nombre <$origen_mail>\r\n";  
//componer el mensaje que se va a enviar
$mensaje='';
	foreach($_POST as $k => $v){ 
		$mensaje.=ucfirst($k).": $v\n";

	}
//envia el mail	 
mail($destinatario,$asunto,$mensaje,$cabecera);
//redirigir
header("Location:$adondevoy");
?>